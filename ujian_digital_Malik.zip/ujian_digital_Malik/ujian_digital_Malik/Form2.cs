﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ujian_digital_Malik
{
    public partial class Form2 : Form
    {
        MySqlConnection koneksi = new MySqlConnection(
            "server=127.0.0.1;user=root;password=;database=ujian_digital;"
        );

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            txtid.ReadOnly = false;
            txtid.Enabled = true;

            TampilData();
        }


        // MENAMPILKAN DATA
        private void TampilData()
        {
            try
            {
                koneksi.Open();

                string query = "SELECT id, username, password FROM users";

                MySqlDataAdapter da = new MySqlDataAdapter(query, koneksi);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                koneksi.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal menampilkan data: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }

        // TAMBAH DATA
        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "" || txtpassword.Text == "")
            {
                MessageBox.Show("Username dan Password harus diisi!");
                return;
            }

            try
            {
                koneksi.Open();

                string query = "INSERT INTO users (username, password) " +
                               "VALUES (@username, @password)";

                MySqlCommand cmd = new MySqlCommand(query, koneksi);

                cmd.Parameters.AddWithValue("@username", txtusername.Text);
                cmd.Parameters.AddWithValue("@password", txtpassword.Text);

                cmd.ExecuteNonQuery();

                koneksi.Close();

                MessageBox.Show(
                    "Data berhasil ditambahkan!",
                    "Informasi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                TampilData();
                Bersihkan();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal menambahkan data:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }


        // EDIT DATA
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Pilih data yang ingin diedit!");
                return;
            }

            try
            {
                koneksi.Open();

                string query = "UPDATE users SET username=@username, " +
                               "password=@password WHERE id=@id";

                MySqlCommand cmd = new MySqlCommand(query, koneksi);

                cmd.Parameters.AddWithValue("@id", txtid.Text);
                cmd.Parameters.AddWithValue("@username", txtusername.Text);
                cmd.Parameters.AddWithValue("@password", txtpassword.Text);

                cmd.ExecuteNonQuery();

                koneksi.Close();

                MessageBox.Show(
                    "Data berhasil diubah!",
                    "Informasi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                TampilData();
                Bersihkan();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal mengubah data: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }

        // HAPUS DATA
        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Pilih data yang ingin dihapus!");
                return;
            }

            DialogResult hasil = MessageBox.Show(
                "Apakah yakin ingin menghapus data ini?",
                "Konfirmasi",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (hasil == DialogResult.Yes)
            {
                try
                {
                    koneksi.Open();

                    string query = "DELETE FROM users WHERE id=@id";

                    MySqlCommand cmd = new MySqlCommand(query, koneksi);
                    cmd.Parameters.AddWithValue("@id", txtid.Text);

                    cmd.ExecuteNonQuery();

                    koneksi.Close();

                    MessageBox.Show(
                        "Data berhasil dihapus!",
                        "Informasi",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    TampilData();
                    Bersihkan();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Gagal menghapus data: " + ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );

                    if (koneksi.State == ConnectionState.Open)
                        koneksi.Close();
                }
            }
        }

        // KLIK DATA DI DATAGRIDVIEW
        private void dataGridView1_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtid.Text = row.Cells["id"].Value.ToString();
                txtusername.Text = row.Cells["username"].Value.ToString();
                txtpassword.Text = row.Cells["password"].Value.ToString();
            }
        }

        // BATAL / CLEAR
        private void btnBatal_Click(object sender, EventArgs e)
        {
            Bersihkan();
        }

        private void Bersihkan()
        {
            txtid.Clear();
            txtusername.Clear();
            txtpassword.Clear();

            txtusername.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnSoal_Click(object sender, EventArgs e)
        {
            Form3 soal = new Form3();
            soal.Show();
            this.Hide();
        }
    }
}
