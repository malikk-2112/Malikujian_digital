﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ujian_digital_Malik
{
    class Class1
    {
    }
}
