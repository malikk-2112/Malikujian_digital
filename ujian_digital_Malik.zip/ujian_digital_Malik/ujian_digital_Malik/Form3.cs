﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ujian_digital_Malik
{
    public partial class Form3 : Form
    {
        MySqlConnection koneksi = new MySqlConnection(
            "server=127.0.0.1;user=root;password=;database=ujian_digital;"
        );

        public Form3()
        {
            InitializeComponent();
        }

        // =========================
        // FORM LOAD
        // =========================
        private void Form3_Load(object sender, EventArgs e)
        {
            txtidsoal.ReadOnly = true;

            cmbjawaban.Items.Clear();
            cmbjawaban.Items.Add("A");
            cmbjawaban.Items.Add("B");
            cmbjawaban.Items.Add("C");
            cmbjawaban.Items.Add("D");

            TampilData();
        }

        // =========================
        // MENAMPILKAN DATA
        // =========================
        private void TampilData()
        {
            try
            {
                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();

                koneksi.Open();

                string query = "SELECT id_soal, pertanyaan, pilihan_a, " +
                               "pilihan_b, pilihan_c, pilihan_d, jawaban_benar " +
                               "FROM soal";

                MySqlDataAdapter da = new MySqlDataAdapter(query, koneksi);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                koneksi.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal menampilkan data:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }

        // =========================
        // TAMBAH DATA
        // =========================
        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (txtpertanyaan.Text == "" ||
                txta.Text == "" ||
                txtb.Text == "" ||
                txtc.Text == "" ||
                txtd.Text == "" ||
                cmbjawaban.Text == "")
            {
                MessageBox.Show(
                    "Semua data soal harus diisi!",
                    "Peringatan",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            try
            {
                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();

                koneksi.Open();

                string query = "INSERT INTO soal " +
                               "(pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, jawaban_benar) " +
                               "VALUES " +
                               "(@pertanyaan, @a, @b, @c, @d, @jawaban)";

                MySqlCommand cmd = new MySqlCommand(query, koneksi);

                cmd.Parameters.AddWithValue("@pertanyaan", txtpertanyaan.Text);
                cmd.Parameters.AddWithValue("@a", txta.Text);
                cmd.Parameters.AddWithValue("@b", txtb.Text);
                cmd.Parameters.AddWithValue("@c", txtc.Text);
                cmd.Parameters.AddWithValue("@d", txtd.Text);
                cmd.Parameters.AddWithValue("@jawaban", cmbjawaban.Text);

                cmd.ExecuteNonQuery();

                koneksi.Close();

                MessageBox.Show(
                    "Soal berhasil ditambahkan!",
                    "Informasi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                TampilData();
                Bersihkan();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal menambahkan soal:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }

        // =========================
        // EDIT DATA
        // =========================
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtidsoal.Text == "")
            {
                MessageBox.Show(
                    "Pilih soal yang ingin diedit!",
                    "Peringatan",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            if (txtpertanyaan.Text == "" ||
                txta.Text == "" ||
                txtb.Text == "" ||
                txtc.Text == "" ||
                txtd.Text == "" ||
                cmbjawaban.Text == "")
            {
                MessageBox.Show(
                    "Semua data soal harus diisi!",
                    "Peringatan",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            try
            {
                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();

                koneksi.Open();

                string query = "UPDATE soal SET " +
                               "pertanyaan=@pertanyaan, " +
                               "pilihan_a=@a, " +
                               "pilihan_b=@b, " +
                               "pilihan_c=@c, " +
                               "pilihan_d=@d, " +
                               "jawaban_benar=@jawaban " +
                               "WHERE id_soal=@id";

                MySqlCommand cmd = new MySqlCommand(query, koneksi);

                cmd.Parameters.AddWithValue("@id", txtidsoal.Text);
                cmd.Parameters.AddWithValue("@pertanyaan", txtpertanyaan.Text);
                cmd.Parameters.AddWithValue("@a", txta.Text);
                cmd.Parameters.AddWithValue("@b", txtb.Text);
                cmd.Parameters.AddWithValue("@c", txtc.Text);
                cmd.Parameters.AddWithValue("@d", txtd.Text);
                cmd.Parameters.AddWithValue("@jawaban", cmbjawaban.Text);

                cmd.ExecuteNonQuery();

                koneksi.Close();

                MessageBox.Show(
                    "Soal berhasil diubah!",
                    "Informasi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                TampilData();
                Bersihkan();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal mengubah soal:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                if (koneksi.State == ConnectionState.Open)
                    koneksi.Close();
            }
        }

        // =========================
        // HAPUS DATA
        // =========================
        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtidsoal.Text == "")
            {
                MessageBox.Show(
                    "Pilih soal yang ingin dihapus!",
                    "Peringatan",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                return;
            }

            DialogResult hasil = MessageBox.Show(
                "Apakah kamu yakin ingin menghapus soal ini?",
                "Konfirmasi",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (hasil == DialogResult.Yes)
            {
                try
                {
                    if (koneksi.State == ConnectionState.Open)
                        koneksi.Close();

                    koneksi.Open();

                    string query = "DELETE FROM soal WHERE id_soal=@id";

                    MySqlCommand cmd = new MySqlCommand(query, koneksi);

                    cmd.Parameters.AddWithValue("@id", txtidsoal.Text);

                    cmd.ExecuteNonQuery();

                    koneksi.Close();

                    MessageBox.Show(
                        "Soal berhasil dihapus!",
                        "Informasi",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    TampilData();
                    Bersihkan();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Gagal menghapus soal:\n" + ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );

                    if (koneksi.State == ConnectionState.Open)
                        koneksi.Close();
                }
            }
        }

        // =========================
        // KLIK DATA GRIDVIEW
        // =========================
        private void dataGridView1_CellClick(
            object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtidsoal.Text = row.Cells["id_soal"].Value.ToString();
                txtpertanyaan.Text = row.Cells["pertanyaan"].Value.ToString();
                txta.Text = row.Cells["pilihan_a"].Value.ToString();
                txtb.Text = row.Cells["pilihan_b"].Value.ToString();
                txtc.Text = row.Cells["pilihan_c"].Value.ToString();
                txtd.Text = row.Cells["pilihan_d"].Value.ToString();
                cmbjawaban.Text = row.Cells["jawaban_benar"].Value.ToString();
            }
        }

        // =========================
        // BATAL / CLEAR
        // =========================
        private void btnBatal_Click(object sender, EventArgs e)
        {
            Bersihkan();
        }

        private void Bersihkan()
        {
            txtidsoal.Clear();
            txtpertanyaan.Clear();
            txta.Clear();
            txtb.Clear();
            txtc.Clear();
            txtd.Clear();
            cmbjawaban.SelectedIndex = -1;

            txtpertanyaan.Focus();
        }

        private void btnSoal_Click(object sender, EventArgs e)
        {
            Form3 menu = new Form3();
            menu.Show();
            this.Hide();
        }
    }
}
